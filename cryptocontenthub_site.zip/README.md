CryptoContent Hub - Site estático
Arquivos:
- index.html  (página inicial)
- blog.html   (página de blog com exemplos gratuito/premium)
- plans.html  (páginas de planos e instruções de pagamento)

Como publicar:
1. Faça upload desses arquivos para a raiz do seu repositório GitHub.
2. Vá em Settings → Pages e selecione a branch principal (main) e pasta / (root).
3. Aguarde alguns segundos e acesse: https://<seu-usuario>.github.io/<seu-repositorio>/

Observações:
- Este é um site estático. Para processar pagamentos automaticamente é necessário integrar um back-end ou um serviço terciário.
- Para formulários use Formspree, Netlify Forms ou integração própria.
